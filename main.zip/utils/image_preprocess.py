from rembg import remove
from PIL import Image

def preprocess_image(image_path):
    input_img = Image.open(image_path)
    output = remove(input_img)
    output.save("outputs/cleaned.png")
    return "outputs/cleaned.png"
