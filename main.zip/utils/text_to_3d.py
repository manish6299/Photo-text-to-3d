import torch
from shap_e.diffusion.sample import sample_latents
from shap_e.diffusion.gaussian_diffusion import diffusion_from_config
from shap_e.models.download import load_model, load_config
from shap_e.util.notebooks import decode_latent_mesh


def generate_3d_from_text(prompt, output_format="stl", output_path="outputs/model.stl"):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = load_model("text300M", device=device)
    diffusion = diffusion_from_config(load_config("diffusion"))

    latents = sample_latents(
        batch_size=1,
        model=model,
        diffusion=diffusion,
        guidance_scale=15.0,
        model_kwargs=dict(texts=[prompt]),
        progress=True,
        device=device,
        clip_denoised=True,
        use_fp16=torch.cuda.is_available(),
        use_karras=True,
        karras_steps=64,
        sigma_min=0.0001,
        sigma_max=160,
        s_churn=0,
    )

    mesh = decode_latent_mesh(latents[0], output_type=output_format)
    mesh.export(output_path)
    print(f" Model saved to: {output_path}")
    return output_path
