from rembg import remove
from PIL import Image
import numpy as np
import trimesh
import os
import cv2
import matplotlib.pyplot as plt
def process_image_to_3d(image_path, output_format='stl'):
    # Remove background
    input_image = Image.open(image_path)
    output_image = remove(input_image)
    output_image.save("outputs/cleaned.png")

    # Dummy 3D shape generation 
    mesh = trimesh.creation.icosphere(radius=1.0)
    output_file = f"outputs/image_model.{output_format}"
    mesh.export(output_file)
    return output_file
