import trimesh
import pyrender
import matplotlib.pyplot as plt

def visualize_model(filepath):
    mesh = trimesh.load(filepath)
    scene = pyrender.Scene()
    mesh = pyrender.Mesh.from_trimesh(mesh)
    scene.add(mesh)
    pyrender.Viewer(scene, use_raymond_lighting=True)
