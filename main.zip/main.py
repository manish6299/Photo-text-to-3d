import argparse
import os
from utils.text_to_3d import generate_3d_from_text
from utils.image_preprocess import preprocess_image  
from utils.image_to_3d import process_image_to_3d  
parser = argparse.ArgumentParser()
parser.add_argument('--image', type=str, help='Path to the input image')
parser.add_argument('--text', type=str, help='Text prompt')
parser.add_argument('--output_format', type=str, choices=['stl', 'obj'], default='stl', help='Output 3D format')
args = parser.parse_args()

output_path = os.path.join("outputs", f"model.{args.output_format}")

if args.text:
    generate_3d_from_text(args.text, output_format=args.output_format, output_path=output_path)
elif args.image:
    processed_image = preprocess_image(args.image)

    print("Image processing not yet implemented.")
else:
    print("Please provide either --text or --image input.")
